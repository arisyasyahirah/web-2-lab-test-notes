<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <title>Car Shop Management Application</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
              integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" 
              crossorigin="anonymous">
    </head>
    <body>
        <div class="container">
            <h1>Application MVC system for Car Shop Management</h1>
            <br>
            <div class="list-group">
                <a href="${pageContext.request.contextPath}/list" class="list-group-item list-group-item-action">
                    All Car List
                </a>
                <a href="${pageContext.request.contextPath}/new" class="list-group-item list-group-item-action">
                    Add a New Car
                </a>
                <a href="${pageContext.request.contextPath}/list" class="list-group-item list-group-item-action">
                    Edit Car
                </a>
            </div>
        </div>
    </body>
</html>