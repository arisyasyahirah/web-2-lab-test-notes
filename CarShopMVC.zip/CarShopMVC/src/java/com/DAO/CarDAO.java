package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.Model.Car;

public class CarDAO {
    
    // Database connection parameters - UPDATE THESE!
    private String jdbcURL = "jdbc:mysql://localhost:3306/carshop?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private String jdbcUsername = "root";
    private String jdbcPassword = "admin";  // <--- CHANGE THIS IF YOU HAVE A PASSWORD!
    
    // SQL Queries
    private static final String INSERT_CAR_SQL = "INSERT INTO CarPricelist (Brand, Model, Cyclinder, Price) VALUES (?, ?, ?, ?);";
    private static final String SELECT_CAR_BY_ID = "SELECT Car_id, Brand, Model, Cyclinder, Price FROM CarPricelist WHERE Car_id = ?";
    private static final String SELECT_ALL_CARS = "SELECT * FROM CarPricelist";
    private static final String DELETE_CAR_SQL = "DELETE FROM CarPricelist WHERE Car_id = ?;";
    private static final String UPDATE_CAR_SQL = "UPDATE CarPricelist SET Brand = ?, Model = ?, Cyclinder = ?, Price = ? WHERE Car_id = ?;";
    
    public CarDAO() {
        // Load MySQL driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("MySQL JDBC Driver loaded successfully!");
        } catch (ClassNotFoundException e) {
            System.err.println("Failed to load MySQL JDBC Driver!");
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    protected Connection getConnection() {
        Connection connection = null;
        try {
            System.out.println("Attempting to connect to database...");
            System.out.println("URL: " + jdbcURL);
            System.out.println("Username: " + jdbcUsername);
            
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            
            if (connection != null) {
                System.out.println("Database connected successfully!");
            } else {
                System.err.println("Failed to make connection!");
            }
            
        } catch (SQLException e) {
            System.err.println("Database connection FAILED!");
            System.err.println("Error Code: " + e.getErrorCode());
            System.err.println("SQL State: " + e.getSQLState());
            System.err.println("Message: " + e.getMessage());
            e.printStackTrace();
        }
        return connection;
    }
    
    public void insertCar(Car car) throws SQLException {
        System.out.println("Inserting car: " + car.getBrand() + " " + car.getModel());
        
        try (Connection connection = getConnection()) {
            if (connection == null) {
                throw new SQLException("Cannot get database connection!");
            }
            
            try (PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CAR_SQL)) {
                preparedStatement.setString(1, car.getBrand());
                preparedStatement.setString(2, car.getModel());
                preparedStatement.setInt(3, car.getCylinder());
                preparedStatement.setDouble(4, car.getPrice());
                preparedStatement.executeUpdate();
                System.out.println("Car inserted successfully!");
            }
        } catch (SQLException e) {
            System.err.println("Error inserting car: " + e.getMessage());
            printSQLException(e);
            throw e;
        }
    }
    
    public Car selectCar(int carId) {
        System.out.println("Selecting car with ID: " + carId);
        Car car = null;
        
        try (Connection connection = getConnection()) {
            if (connection == null) {
                throw new SQLException("Cannot get database connection!");
            }
            
            try (PreparedStatement preparedStatement = connection.prepareStatement(SELECT_CAR_BY_ID)) {
                preparedStatement.setInt(1, carId);
                ResultSet rs = preparedStatement.executeQuery();
                
                while (rs.next()) {
                    String brand = rs.getString("Brand");
                    String model = rs.getString("Model");
                    int cylinder = rs.getInt("Cyclinder");
                    double price = rs.getDouble("Price");
                    car = new Car(carId, brand, model, cylinder, price);
                    System.out.println("Car found: " + brand + " " + model);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error selecting car: " + e.getMessage());
            printSQLException(e);
        }
        return car;
    }
    
    public List<Car> selectAllCars() {
        List<Car> cars = new ArrayList<>();
        System.out.println("Selecting all cars...");
        
        try (Connection connection = getConnection()) {
            if (connection == null) {
                System.err.println("Connection is NULL! Check your database settings.");
                return cars;  // Return empty list
            }
            
            System.out.println("Connection obtained successfully!");
            
            try (PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_CARS)) {
                ResultSet rs = preparedStatement.executeQuery();
                
                while (rs.next()) {
                    int carId = rs.getInt("Car_id");
                    String brand = rs.getString("Brand");
                    String model = rs.getString("Model");
                    int cylinder = rs.getInt("Cyclinder");
                    double price = rs.getDouble("Price");
                    cars.add(new Car(carId, brand, model, cylinder, price));
                }
                
                System.out.println("Found " + cars.size() + " cars in database.");
            }
        } catch (SQLException e) {
            System.err.println("Error in selectAllCars: " + e.getMessage());
            printSQLException(e);
        }
        
        return cars;
    }
    
    public boolean deleteCar(int carId) throws SQLException {
        boolean rowDeleted = false;
        System.out.println("Deleting car with ID: " + carId);
        
        try (Connection connection = getConnection()) {
            if (connection == null) {
                throw new SQLException("Cannot get database connection!");
            }
            
            try (PreparedStatement statement = connection.prepareStatement(DELETE_CAR_SQL)) {
                statement.setInt(1, carId);
                rowDeleted = statement.executeUpdate() > 0;
                System.out.println("Delete successful: " + rowDeleted);
            }
        } catch (SQLException e) {
            System.err.println("Error deleting car: " + e.getMessage());
            printSQLException(e);
            throw e;
        }
        return rowDeleted;
    }
    
    public boolean updateCar(Car car) throws SQLException {
        boolean rowUpdated = false;
        System.out.println("Updating car with ID: " + car.getCarId());
        
        try (Connection connection = getConnection()) {
            if (connection == null) {
                throw new SQLException("Cannot get database connection!");
            }
            
            try (PreparedStatement statement = connection.prepareStatement(UPDATE_CAR_SQL)) {
                statement.setString(1, car.getBrand());
                statement.setString(2, car.getModel());
                statement.setInt(3, car.getCylinder());
                statement.setDouble(4, car.getPrice());
                statement.setInt(5, car.getCarId());
                rowUpdated = statement.executeUpdate() > 0;
                System.out.println("Update successful: " + rowUpdated);
            }
        } catch (SQLException e) {
            System.err.println("Error updating car: " + e.getMessage());
            printSQLException(e);
            throw e;
        }
        return rowUpdated;
    }
    
    private void printSQLException(SQLException ex) {
        System.err.println("SQL Exception Details:");
        for (Throwable e : ex) {
            if (e instanceof SQLException) {
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}