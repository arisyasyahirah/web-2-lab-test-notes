package com.lab.controller;

import com.lab.bean.StudentBean;
import com.lab.bean.SubjectBean;
import com.lab.dao.SubjectDAO;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SubjectServlet extends HttpServlet {
    
    private SubjectDAO subjectDAO = new SubjectDAO();
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        StudentBean user = (session != null) ? (StudentBean) session.getAttribute("loggedUser") : null;
        
        // Redirect if not logged in
        if (user == null) {
            response.sendRedirect("login.html");
            return;
        }
        
        String action = request.getParameter("action");
        String matricNo = user.getMatricNo();
        
        if ("delete".equals(action)) {
            // DELETE subject
            int id = Integer.parseInt(request.getParameter("id"));
            subjectDAO.deleteSubject(id, matricNo);
            response.sendRedirect("SubjectServlet?action=view");
            
        } else if ("edit".equals(action)) {
            // Show edit form (GET request)
            int id = Integer.parseInt(request.getParameter("id"));
            SubjectBean subject = subjectDAO.getSubjectById(id);
            request.setAttribute("subject", subject);
            request.getRequestDispatcher("subjects/updateSubject.jsp").forward(request, response);
            
        } else {
            // READ - View all subjects (default)
            List<SubjectBean> subjects = subjectDAO.getSubjectsByMatricNo(matricNo);
            request.setAttribute("subjects", subjects);
            request.getRequestDispatcher("subjects/viewSubject.jsp").forward(request, response);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession(false);
        StudentBean user = (session != null) ? (StudentBean) session.getAttribute("loggedUser") : null;
        
        if (user == null) {
            response.sendRedirect("login.html");
            return;
        }
        
        String action = request.getParameter("action");
        String matricNo = user.getMatricNo();
        
        if ("add".equals(action)) {
            // CREATE - Add new subject
            SubjectBean subject = new SubjectBean();
            subject.setMatricNo(matricNo);
            subject.setSubjectCode(request.getParameter("subjectCode"));
            subject.setSubjectName(request.getParameter("subjectName"));
            subjectDAO.addSubject(subject);
            response.sendRedirect("SubjectServlet?action=view");
            
        } else if ("update".equals(action)) {
            // UPDATE - Edit subject
            SubjectBean subject = new SubjectBean();
            subject.setId(Integer.parseInt(request.getParameter("id")));
            subject.setMatricNo(matricNo);
            subject.setSubjectCode(request.getParameter("subjectCode"));
            subject.setSubjectName(request.getParameter("subjectName"));
            subjectDAO.updateSubject(subject);
            response.sendRedirect("SubjectServlet?action=view");
        }
    }
}