<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.lab.bean.StudentBean"%>
<%@page import="com.lab.bean.SubjectBean"%>
<%
    StudentBean user = (StudentBean) session.getAttribute("loggedUser");
    if (user == null) {
        response.sendRedirect("login.html");
        return;
    }
    SubjectBean subject = (SubjectBean) request.getAttribute("subject");
    if (subject == null) {
        response.sendRedirect("SubjectServlet?action=view");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Update Subject</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow" style="max-width: 500px; margin: auto;">
            <div class="card-header bg-warning">
                <h4>Update Subject</h4>
            </div>
            <div class="card-body">
                <form action="SubjectServlet" method="POST">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="id" value="<%= subject.getId() %>">
                    <div class="mb-3">
                        <label>Subject Code:</label>
                        <input type="text" name="subjectCode" value="<%= subject.getSubjectCode() %>" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Subject Name:</label>
                        <input type="text" name="subjectName" value="<%= subject.getSubjectName() %>" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-warning">Update</button>
                    <a href="SubjectServlet?action=view" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</body>
</html>