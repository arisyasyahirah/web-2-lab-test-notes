<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.lab.bean.StudentBean"%>
<%
    StudentBean user = (StudentBean) session.getAttribute("loggedUser");
    if (user == null) {
        response.sendRedirect("login.html");
        return;
    }
%>
<!DOCTYPE html>
<html>
<head>
    <title>Register Subject</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow" style="max-width: 500px; margin: auto;">
            <div class="card-header bg-success text-white">
                <h4>Register New Subject</h4>
            </div>
            <div class="card-body">
                <form action="/lab_7/SubjectServlet" method="POST">
                    <input type="hidden" name="action" value="add">
                    <div class="mb-3">
                        <label>Subject Code:</label>
                        <input type="text" name="subjectCode" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label>Subject Name:</label>
                        <input type="text" name="subjectName" class="form-control" required>
                    </div>
                    <button type="submit" class="btn btn-success">Register</button>
                    <a href="SubjectServlet?action=view" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</body>
</html>