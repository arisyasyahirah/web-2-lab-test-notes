<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.lab.bean.StudentBean"%>
<%@page import="com.lab.bean.SubjectBean"%>
<%@page import="java.util.List"%>
<%
    StudentBean user = (StudentBean) session.getAttribute("loggedUser");
    if (user == null) {
        response.sendRedirect("login.html");
        return;
    }
    List<SubjectBean> subjects = (List<SubjectBean>) request.getAttribute("subjects");
%>
<!DOCTYPE html>
<html>
<head>
    <title>My Subjects</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h3>My Subjects - <%= user.getFullname() %> (<%= user.getMatricNo() %>)</h3>
            </div>
            <div class="card-body">
                <a href="registerSubject.jsp" class="btn btn-success mb-3">+ Add New Subject</a>
                
                <table class="table table-bordered">
                    <thead class="table-dark">
                        <tr><th>ID</th><th>Subject Code</th><th>Subject Name</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        <% if (subjects != null && !subjects.isEmpty()) {
                            for (SubjectBean s : subjects) { %>
                            <tr>
                                <td><%= s.getId() %></td>
                                <td><%= s.getSubjectCode() %></td>
                                <td><%= s.getSubjectName() %></td>
                                <td>
                                    <a href="SubjectServlet?action=edit&id=<%= s.getId() %>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="SubjectServlet?action=delete&id=<%= s.getId() %>" class="btn btn-danger btn-sm" onclick="return confirm('Delete this subject?')">Delete</a>
                                </td>
                            </tr>
                        <% } } else { %>
                            <tr><td colspan="4" class="text-center">No subjects registered yet.</td></tr>
                        <% } %>
                    </tbody>
                </table>
                <a href="dashboard.jsp" class="btn btn-secondary">Back to Dashboard</a>
            </div>
        </div>
    </div>
</body>
</html>