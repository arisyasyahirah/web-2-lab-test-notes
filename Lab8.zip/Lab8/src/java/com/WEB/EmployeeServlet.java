package com.WEB;

import com.DAO.EmployeeDAO;
import com.Model.Employee;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;


// NO @WebServlet annotation here — mapping is in web.xml instead
public class EmployeeServlet extends HttpServlet {

    private EmployeeDAO employeeDAO;

    // init() runs ONCE when server starts
    // creates the DAO so it's ready to use
    @Override
    public void init() {
        employeeDAO = new EmployeeDAO();
    }

    // ALL post requests go to doGet
    // this means we handle everything in one place
    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    // MAIN METHOD — reads URL path, decides what to do
    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        // getServletPath() reads the URL after project name
        // e.g. localhost:8080/Lab8/new    → action = "/new"
        // e.g. localhost:8080/Lab8/delete → action = "/delete"
        String action = request.getServletPath();

        try {
            switch (action) {
                case "/new":
                    showNewForm(request, response);
                    break;
                case "/insert":
                    insertEmployee(request, response);
                    break;
                case "/edit":
                    showEditForm(request, response);
                    break;
                case "/update":
                    updateEmployee(request, response);
                    break;
                case "/delete":
                    deleteEmployee(request, response);
                    break;
                default:
                    // /list and anything else → show the list
                    listEmployee(request, response);
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    // READ ALL
    // Gets all employees from DB, puts in request, forwards to list JSP
    private void listEmployee(HttpServletRequest request,
                               HttpServletResponse response)
            throws SQLException, IOException, ServletException {

        List<Employee> listEmployee = employeeDAO.selectAllEmployees();

        // setAttribute = pass data to JSP
        // JSP accesses this with ${listEmployee}
        request.setAttribute("listEmployee", listEmployee);

        RequestDispatcher dispatcher =
            request.getRequestDispatcher("employeeList.jsp");
        dispatcher.forward(request, response);
    }

    // SHOW ADD FORM
    // Just forwards to form JSP — no employee attribute set
    // JSP checks: employee == null → shows "Add New Employee"
    private void showNewForm(HttpServletRequest request,
                              HttpServletResponse response)
            throws ServletException, IOException {

        RequestDispatcher dispatcher =
            request.getRequestDispatcher("employeeForm.jsp");
        dispatcher.forward(request, response);
    }

    // SHOW EDIT FORM
    // Gets employee by id, puts in request, forwards to same form JSP
    // JSP checks: employee != null → shows "Edit Employee" pre-filled
    private void showEditForm(HttpServletRequest request,
                               HttpServletResponse response)
            throws SQLException, ServletException, IOException {

        // Read ?id=2 from the URL
        int id = Integer.parseInt(request.getParameter("id").trim());

        Employee existingEmployee = employeeDAO.selectEmployee(id);

        // setAttribute = pass employee object to JSP
        // JSP accesses this with ${employee.name} etc
        request.setAttribute("employee", existingEmployee);

        RequestDispatcher dispatcher =
            request.getRequestDispatcher("employeeForm.jsp");
        dispatcher.forward(request, response);
    }

    // INSERT (Create)
    // Reads form fields, builds Employee, inserts, redirects to list
    private void insertEmployee(HttpServletRequest request,
                                 HttpServletResponse response)
            throws SQLException, IOException {

        // getParameter reads what user typed in form fields
        String name     = request.getParameter("name");
        String email    = request.getParameter("email");
        String position = request.getParameter("position");

        // No id needed — DB auto generates it
        Employee newEmployee = new Employee(name, email, position);
        employeeDAO.insertEmployee(newEmployee);

        // sendRedirect sends user BACK to list page after insert
        response.sendRedirect("list");
    }

    // UPDATE
    // Reads form fields INCLUDING hidden id, updates, redirects to list
    private void updateEmployee(HttpServletRequest request,
                                 HttpServletResponse response)
            throws SQLException, IOException {

        // id comes from hidden input in the form
        int    id       = Integer.parseInt(request.getParameter("id").trim());
        String name     = request.getParameter("name");
        String email    = request.getParameter("email");
        String position = request.getParameter("position");

        // Need id this time so DB knows WHICH row to update
        Employee employee = new Employee(id, name, email, position);
        employeeDAO.updateEmployee(employee);

        response.sendRedirect("list");
    }

    // DELETE
    // Reads id from URL, deletes that row, redirects to list
    private void deleteEmployee(HttpServletRequest request,
                                 HttpServletResponse response)
            throws SQLException, IOException {

        // id comes from ?id=2 in the URL link
        int id = Integer.parseInt(request.getParameter("id"));
        employeeDAO.deleteEmployee(id);

        response.sendRedirect("list");
    }
}