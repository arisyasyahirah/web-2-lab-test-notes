/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author user
 */
class DBconnection {
    private static final String jdbcURL = "jdbc:mysql://localhost:3306/company";
    private static final String jdbcUsername = "admin";
    private static final String jdbcPassword = "admin";
    
    public static Connection getConnection(){
        Connection connection =null;
        try{
            Class.forName("com.mysql.cj/jdbc/Driver");
            connection = DriverManager.getConnection(jdbcURL,jdbcUsername, jdbcPassword);
            
        }catch (ClassNotFoundException | SQLException e){
            e.printStackTrace();
        }
        return connection;
    }
}
