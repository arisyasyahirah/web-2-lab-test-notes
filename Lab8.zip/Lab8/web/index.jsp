<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <title>User Management Application</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
              integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" 
              crossorigin="anonymous">
    </head>
    <body>
        <div class="container">
            <h1>Application MVC system for Employee Management</h1>
            <br>
            <div class="list-group">
                <a href="${pageContext.request.contextPath}/list" >
                    All Employee List
                </a>
                <a href="${pageContext.request.contextPath}/new" >
                    Add a New Employee
                </a>
                <a href="${pageContext.request.contextPath}/list" >
                    Edit Employee
                </a>
            </div>
        </div>
    </body>
</html>