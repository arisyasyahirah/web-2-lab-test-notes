<%@ page language="java" contentType="text/html; charset=UTF-8"
         pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c"%>
<!DOCTYPE html>
<html>
    <head>
        <title>Employee Management Application</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    </head>
    <body>
        <header>
            <nav class="navbar navbar-expand-md navbar-dark" style="background-color: tomato">
                <div>
                    <a href="" class="navbar-brand"> Employee Management App </a>
                </div>
                <ul class="navbar-nav">
                    <li><a href="<%=request.getContextPath()%>/list" class="nav-link">Employees</a></li>
                </ul>
            </nav>
        </header>
        <br>
        <div class="container col-md-5">
            <div class="card">
                <div class="card-body">
                    <c:choose>
                        <c:when test="${employee != null}">
                            <form action="update" method="post">
                                <h2>Edit Employee</h2>
                                <input type="hidden" name="id" value="<c:out value='${employee.id}' />" />
                                <fieldset class="form-group">
                                    <label>Employee Name</label>
                                    <input type="text" value="<c:out value='${employee.name}' />" class="form-control" name="name" required="required">
                                </fieldset>
                                <fieldset class="form-group">
                                    <label>Employee Email</label>
                                    <input type="text" value="<c:out value='${employee.email}' />" class="form-control" name="email">
                                </fieldset>
                                <fieldset class="form-group">
                                    <label>Employee Position</label>
                                    <input list="positionList" id="position" class="form-control" name="position" value="<c:out value='${employee.position}' />">
                                    <datalist id="positionList">
                                        <option value="Manager">
                                        <option value="Head of Dept">
                                        <option value="Supervisor">
                                        <option value="Director">
                                    </datalist>
                                </fieldset>
                                <button type="submit" class="btn btn-success">Save</button>
                            </form>
                        </c:when>
                        <c:otherwise>
                            <form action="insert" method="post">
                                <h2>Add New Employee</h2>
                                <fieldset class="form-group">
                                    <label>Employee Name</label>
                                    <input type="text" value="" class="form-control" name="name" required="required">
                                </fieldset>
                                <fieldset class="form-group">
                                    <label>Employee Email</label>
                                    <input type="text" value="" class="form-control" name="email">
                                </fieldset>
                                <fieldset class="form-group">
                                    <label>Employee Position</label>
                                    <input list="positionList" id="position" class="form-control" name="position" value="">
                                    <datalist id="positionList">
                                        <option value="Manager">
                                        <option value="Head of Dept">
                                        <option value="Supervisor">
                                        <option value="Director">
                                    </datalist>
                                </fieldset>
                                <button type="submit" class="btn btn-success">Save</button>
                            </form>
                        </c:otherwise>
                    </c:choose>
                </div>
            </div>
        </div>
    </body>
</html>